import React from "react";
import { Navigate, Outlet } from "react-router";

const ProtectedRoute = () => {

  const token = localStorage.getItem("token_admin_house_of_geniuses");

  return token ? <Outlet /> : <Navigate to={"/"} />;
};

export default ProtectedRoute;
