import React from 'react'

const ProtectedWithoutToken = () => {
  return (
    <div>ProtectedWithoutToken</div>
  )
}

export default ProtectedWithoutToken